import os
import csv
from io import StringIO
from pyspark import SparkContext

# Set Python paths
os.environ['PYSPARK_PYTHON'] = r'C:/Users/Dell/AppData/Local/Programs/Python/Python310/python.exe'
os.environ['PYSPARK_DRIVER_PYTHON'] = r'C:/Users/Dell/AppData/Local/Programs/Python/Python310/python.exe'

# Properly parse CSV using Python csv module
def parse_color_line(line):
    try:
        # Use csv.reader to safely split line
        parts = next(csv.reader(StringIO(line)))
        color = parts[10].strip().lower()
        price = float(parts[14])
        # Remove numeric values accidentally appearing as colors
        if not color or color.isdigit():
            return None
        return (color, (1, price))
    except:
        return None

# Reducer to add count and price
def reduce_color_stats(a, b):
    return (a[0] + b[0], a[1] + b[1])

if __name__ == "__main__":
    sc = SparkContext("local", "Color Sales Analytics")

    # Load CSV file
    lines = sc.textFile("E:/FULL-Stack_Projects/AI -ML/car_prices.csv")

    # Parse lines, filter invalid entries
    parsed = lines.map(parse_color_line).filter(lambda x: x is not None)

    # Aggregate data
    color_stats = parsed.reduceByKey(reduce_color_stats)

    # Sort by number of vehicles sold (descending)
    sorted_stats = sorted(color_stats.collect(), key=lambda x: x[1][0], reverse=True)

    # Output
    for color, (count, total_price) in sorted_stats:
        print(f"Color: {color.title()} | Vehicles Sold: {count:,} | Total Sales Value: ${total_price:,.2f}")

    sc.stop()
