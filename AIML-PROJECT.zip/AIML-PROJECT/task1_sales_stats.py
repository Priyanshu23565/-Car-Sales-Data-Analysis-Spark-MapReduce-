import os
from pyspark import SparkContext
import datetime

# Set Python environment paths
os.environ['PYSPARK_PYTHON'] = r'C:/Users/Dell/AppData/Local/Programs/Python/Python310/python.exe'
os.environ['PYSPARK_DRIVER_PYTHON'] = r'C:/Users/Dell/AppData/Local/Programs/Python/Python310/python.exe'

def parse_line(line):
    parts = line.split(",")
    try:
        year_manufacture = int(parts[0])
        selling_price = float(parts[14])
        odometer = float(parts[9])
        sale_date_str = parts[15]
        sale_year = datetime.datetime.strptime(sale_date_str[:15], "%a %b %d %Y").year
        age = sale_year - year_manufacture
        return (sale_year, (1, selling_price, odometer, age))
    except:
        return None

def reduce_stats(a, b):
    # Sum counts, prices, odometers, and ages
    return (a[0] + b[0], a[1] + b[1], a[2] + b[2], a[3] + b[3])

if __name__ == "__main__":
    sc = SparkContext("local", "Car Sales Stats")

    lines = sc.textFile("E:/FULL-Stack_Projects/AI -ML/car_prices.csv")
    parsed = lines.map(parse_line).filter(lambda x: x is not None)
    
    yearly_stats = parsed.reduceByKey(reduce_stats)

    # Sort by year for nice output
    for year, (count, total_price, total_odo, total_age) in sorted(yearly_stats.collect()):
        avg_odo = total_odo / count
        avg_age = total_age / count
        print(f"{year}\t[{count}, {int(total_price)}, {avg_odo:.2f}, {avg_age:.2f}]")

    sc.stop()
