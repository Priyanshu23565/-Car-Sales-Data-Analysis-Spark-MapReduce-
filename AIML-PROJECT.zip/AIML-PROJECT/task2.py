import os
from pyspark import SparkContext
import datetime

# Set Python environment paths (tune kar lena apne machine ke hisaab se)
os.environ['PYSPARK_PYTHON'] = r'C:/Users/Dell/AppData/Local/Programs/Python/Python310/python.exe'
os.environ['PYSPARK_DRIVER_PYTHON'] = r'C:/Users/Dell/AppData/Local/Programs/Python/Python310/python.exe'

def parse_line(line):
    parts = line.split(",")
    try:
        year_manufacture = int(parts[0])
        brand = parts[1]
        selling_price = float(parts[14])
        odometer = float(parts[9])
        sale_date_str = parts[15]
        sale_year = datetime.datetime.strptime(sale_date_str[:15], "%a %b %d %Y").year
        age = sale_year - year_manufacture
        # Key is tuple (year, brand)
        return ((sale_year, brand), (1, selling_price, odometer, age))
    except:
        return None

def reduce_stats(a, b):
    # Combine tuples: (count, total_price, total_odo, total_age)
    return (a[0] + b[0], a[1] + b[1], a[2] + b[2], a[3] + b[3])

if __name__ == "__main__":
    sc = SparkContext("local", "Yearly Brand Sales Stats")

    # Load file (update path as per your file)
    lines = sc.textFile("E:/FULL-Stack_Projects/AI -ML/car_prices.csv")
    
    # Parse lines, filter None
    parsed = lines.map(parse_line).filter(lambda x: x is not None)
    
    # Reduce by key (year, brand)
    yearly_brand_stats = parsed.reduceByKey(reduce_stats)
    
    # Collect and print results
    for (year, brand), (count, total_price, total_odo, total_age) in sorted(yearly_brand_stats.collect()):
        print(f"Year: {year}, Brand: {brand}")
        print(f"Number of vehicles sold: {count}")
        print(f"Total selling price: ${total_price:,.2f}")
        print(f"Average odometer reading: {total_odo / count:.2f}")
        print(f"Average age: {total_age / count:.2f}")
        print("------")

    sc.stop()
