import os
import csv
from io import StringIO
from pyspark import SparkContext

os.environ['PYSPARK_PYTHON'] = r'C:/Users/Dell/AppData/Local/Programs/Python/Python310/python.exe'
os.environ['PYSPARK_DRIVER_PYTHON'] = r'C:/Users/Dell/AppData/Local/Programs/Python/Python310/python.exe'

def parse_color_pair_line(line):
    try:
        parts = next(csv.reader(StringIO(line)))
        exterior = parts[10].strip().lower()
        interior = parts[11].strip().lower()
        if not exterior or not interior or exterior.isdigit() or interior.isdigit():
            return None
        return ((exterior, interior), 1)
    except:
        return None

if __name__ == "__main__":
    sc = SparkContext("local", "Exterior-Interior Color Combinations")

    lines = sc.textFile("E:/FULL-Stack_Projects/AI -ML/car_prices.csv")
    header = lines.first()
    lines = lines.filter(lambda line: line != header)

    parsed = lines.map(parse_color_pair_line).filter(lambda x: x is not None)
    pair_counts = parsed.reduceByKey(lambda a, b: a + b)

    pairs = pair_counts.collect()
    pairs_sorted = sorted(pairs, key=lambda x: x[1], reverse=True)

    # Print aligned output
    for (exterior, interior), count in pairs_sorted:
        pair_str = f'["{exterior}","{interior}"]'
        print(f'{pair_str:<22}\t{count}')

    sc.stop()
